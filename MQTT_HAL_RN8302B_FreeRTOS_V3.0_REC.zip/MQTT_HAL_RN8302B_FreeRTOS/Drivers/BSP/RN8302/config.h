#ifndef _CONFIG_H
#define _CONFIG_H

#define TEST_8302B
//#define TEST_8209D

#endif
